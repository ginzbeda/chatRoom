using namespace std;

int receive_message(int connfd, char *message);
int send_message(int connfd, char *message);